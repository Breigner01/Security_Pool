The eyes cannot see everything, maybe you should try to put some filters on them.

(it's a funny joke, don't do it, download stegsolve instead)
